# Arrow Slither Escape PWA

Complete GitHub Pages PWA package.

Upload the contents of this folder to your GitHub Pages site root:
- index.html
- manifest.webmanifest
- sw.js
- icons/

Notes:
- GitHub Pages must be served over HTTPS for native browser install prompts.
- Android Chrome may show the native install prompt after the service worker activates; this build also shows a custom fallback prompt.
- iOS install is manual: open in Safari, tap Share, then Add to Home Screen.
- If you tested an older build, clear site data or use the new dismiss key by refreshing after upload.
